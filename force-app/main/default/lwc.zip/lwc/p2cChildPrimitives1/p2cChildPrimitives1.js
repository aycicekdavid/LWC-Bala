import { api, LightningElement } from 'lwc';

export default class P2cChildPrimitives1 extends LightningElement {
    @api student;
    @api title;
}