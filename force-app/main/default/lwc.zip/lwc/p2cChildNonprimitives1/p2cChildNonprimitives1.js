import { api, LightningElement } from 'lwc';

export default class P2cChildNonprimitives1 extends LightningElement {
    @api detail;
}