import { LightningElement } from 'lwc';

export default class P2cParentPrimitives1 extends LightningElement {}