import { api, LightningElement } from 'lwc';

export default class P2cChildNonprimitives2 extends LightningElement {
    @api locationDetail;
}