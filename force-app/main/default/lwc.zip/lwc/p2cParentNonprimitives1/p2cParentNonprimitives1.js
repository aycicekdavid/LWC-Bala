import { LightningElement } from 'lwc';

export default class P2cParentNonprimitives1 extends LightningElement {
    //info = "Balakrishna";
    info = {
        name: "Balakrishna",
        city: "Hyderabad",
        title: "Salesforce Developer"
    }
}