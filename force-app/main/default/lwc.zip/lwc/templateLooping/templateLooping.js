import { LightningElement } from 'lwc';

export default class TemplateLooping extends LightningElement {
    fruits = ["Apple", "Orange", "Banana", "Dragon", "Pineapple"];
}