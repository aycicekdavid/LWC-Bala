import { LightningElement } from 'lwc';

export default class StudentDetail extends LightningElement {
    student = {
        name : "Bala",
        city : "Hyderabad"
    }
}